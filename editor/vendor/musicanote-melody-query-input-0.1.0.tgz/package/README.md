# @musicanote/melody-query-input

Portable React editor for entering a melody or rhythm with a piano keyboard and rendered staff notation. It owns the note-editing UI but does not include a search API, corpus, database, or playback engine.

## Install from the local package

Build and pack this directory from the MusicSearch repository:

```sh
pnpm run pack:melody-query-input
```

Then install the generated tarball into another React project, along with the peer dependencies:

```sh
pnpm add ./path/to/musicanote-melody-query-input-0.1.0.tgz react verovio@^6.3.0
```

## Use

```tsx
import { useState } from 'react';
import {
  MelodyQueryInput,
  type Query,
} from '@musicanote/melody-query-input';
import '@musicanote/melody-query-input/style.css';

export function Composer() {
  const [query, setQuery] = useState<Query>({
    version: 1,
    mode: 'melody_rhythm',
    meter: '4/4',
    startsOnDownbeat: true,
    events: [],
  });

  return <MelodyQueryInput
    value={query}
    onChange={setQuery}
    onSearch={next => console.log('Connect your search here:', next)}
    onPreview={next => console.log('Connect your own playback here:', next)}
  />;
}
```

For a fully controlled editor, pass `value={query}` instead of `defaultValue`. Each edit is emitted through `onChange`. `onSearch` and `onPreview` are optional host callbacks; they are never called automatically.

The public query shape is versioned and portable:

```ts
{
  version: 1,
  mode: 'melody_rhythm',
  meter: '4/4',
  startsOnDownbeat: true,
  events: [{
    id: 'q-…', kind: 'note', pitchMidi: 60,
    spelling: 'C4', durationRatio: 1
  }]
}
```

Durations are measured in quarter-note beats (`1` = quarter note, `.5` = eighth note). The editor includes keyboard/staff entry, pitch adjustment, per-event duration editing, rests, ties, tuplets, undo/redo, query import/export, and optional microphone humming input. The key signature currently defaults to C major, and the clef is inferred from the entered pitch range. Verovio is loaded dynamically as WebAssembly; the consuming app's bundler must support the `verovio/wasm` package entry.
